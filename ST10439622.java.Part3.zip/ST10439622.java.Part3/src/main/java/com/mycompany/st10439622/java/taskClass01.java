package com.mycompany.st10439622.java;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class taskClass01 {

    private static ArrayList<String> developerNames = new ArrayList<>();
    private static ArrayList<String> taskNames = new ArrayList<>();
    private static ArrayList<Integer> taskDurations = new ArrayList<>();
    private static ArrayList<String> taskStatuses = new ArrayList<>();

    public static void addTask(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        // Store task details in arrays
        developerNames.add(developerDetails);
        taskNames.add(taskName);
        taskDurations.add(taskDuration);
        taskStatuses.add(taskStatus);

        JOptionPane.showMessageDialog(null, "Task added successfully");
    }

    public static void displayTasksWithStatusDone() {
        StringBuilder report = new StringBuilder("Tasks with status 'Done':\n");
        for (int i = 0; i < taskNames.size(); i++) {
            if ("Done".equals(taskStatuses.get(i))) {
                report.append(String.format("Developer: %s, Task Name: %s, Task Duration: %d hours\n",
                        developerNames.get(i), taskNames.get(i), taskDurations.get(i)));
            }
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    public static void displayTaskWithLongestDuration() {
        int maxDuration = 0;
        int maxIndex = -1;
        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                maxIndex = i;
            }
        }
        if (maxIndex != -1) {
            JOptionPane.showMessageDialog(null, String.format("Developer: %s, Task Duration: %d hours",
                    developerNames.get(maxIndex), maxDuration));
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found");
        }
    }

    public static void searchTaskByName(String searchTerm) {
        boolean found = false;
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).toLowerCase().contains(searchTerm.toLowerCase())) {
                found = true;
                JOptionPane.showMessageDialog(null, String.format("Developer: %s, Task Name: %s, Task Status: %s",
                        developerNames.get(i), taskNames.get(i), taskStatuses.get(i)));
                break;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No tasks found with the given name");
        }
    }

    public static void searchTasksByDeveloper(String developerName) {
        boolean found = false;
        for (int i = 0; i < developerNames.size(); i++) {
            if (developerNames.get(i).equalsIgnoreCase(developerName)) {
                found = true;
                JOptionPane.showMessageDialog(null, String.format("Task Name: %s, Task Status: %s",
                        taskNames.get(i), taskStatuses.get(i)));
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No tasks found assigned to the given developer");
        }
    }

    public static void deleteTaskByName(String taskName) {
        int index = taskNames.indexOf(taskName);
        if (index != -1) {
            developerNames.remove(index);
            taskNames.remove(index);
            taskDurations.remove(index);
            taskStatuses.remove(index);
            JOptionPane.showMessageDialog(null, "Task deleted successfully");
        } else {
            JOptionPane.showMessageDialog(null, "No task found with the given name");
        }
    }

    public static void displayReport() {
        StringBuilder report = new StringBuilder("Task Report:\n");
        for (int i = 0; i < taskNames.size(); i++) {
            report.append(String.format("Developer: %s, Task Name: %s, Task Duration: %d hours, Task Status: %s\n",
                    developerNames.get(i), taskNames.get(i), taskDurations.get(i), taskStatuses.get(i)));
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    // Getter methods for unit testing
    public static ArrayList<String> getDeveloperNames() {
        return developerNames;
    }

    public static ArrayList<String> getTaskNames() {
        return taskNames;
    }

    public static ArrayList<Integer> getTaskDurations() {
        return taskDurations;
    }

    public static ArrayList<String> getTaskStatuses() {
        return taskStatuses;
    }
}
