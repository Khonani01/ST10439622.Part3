package com.mycompany.st10439622.java;


import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class taskClass01Test {

    

    @Test
    public void testAddTask() {
        assertEquals(3, taskClass01.getTaskNames().size());
        assertEquals("Joe Biden", taskClass01.getDeveloperNames().get(0));
        assertEquals("Create Reports For task", taskClass01.getTaskNames().get(2));
    }

    @Test
    public void testDisplayTasksWithStatusDone() {
        taskClass01.displayTasksWithStatusDone();
        // Manually verify output as it is displayed via JOptionPane
    }

    @Test
    public void testDisplayTaskWithLongestDuration() {
        taskClass01.displayTaskWithLongestDuration();
        // Manually verify output as it is displayed via JOptionPane
    }

    @Test
    public void testSearchTaskByName() {
        taskClass01.searchTaskByName("Create Login");
        // Manually verify output as it is displayed via JOptionPane
    }

    @Test
    public void testSearchTasksByDeveloper() {
        taskClass01.searchTasksByDeveloper("Carter");
        // Manually verify output as it is displayed via JOptionPane
    }

    @Test
    public void testDeleteTaskByName() {
        taskClass01.deleteTaskByName("Create Reports For task");
        assertEquals(2, taskClass01.getTaskNames().size());
    }

    @Test
    public void testDisplayReport() {
        taskClass01.displayReport();
        // Manually verify output as it is displayed via JOptionPane
    }
}

