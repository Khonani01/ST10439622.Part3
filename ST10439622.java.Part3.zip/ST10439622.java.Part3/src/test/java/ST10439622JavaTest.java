/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author mutob
 */
public class ST10439622JavaTest {
    
    public ST10439622JavaTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }

    @Test
    public void testMain() {
    }

    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testLoginUser() {
    }

    @Test
    public void testAuthenticate() {
    }

    @Test
    public void testIsValidUsername() {
    }

    @Test
    public void testIsValidPassword() {
    }

    @Test
    public void testShowMainMenu() {
    }

    @Test
    public void testAddTasks() {
    }

    @Test
    public void testShowReport() {
    }

    @Test
    public void testGenerateTaskID() {
    }
    
}
